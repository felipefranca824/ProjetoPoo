package ClassesFuncionais;

import java.util.ArrayList;

public class Compra {
	private double valor;
	private ArrayList<Produto> produtos = new ArrayList<Produto> ();
	public Compra(Produto produto) {
		produtos.add(produto);
		this.valor = produto.getPreco();
	}
	public double getValor() {
		return valor;
	}
	public boolean adicionarProduto(Produto produto) {
		produtos.add(produto);
		return true;
	}
	
	public void setValor(double valor) {
		this.valor = valor;
	}

}
