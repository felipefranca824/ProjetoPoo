package ClassesFuncionais;

import java.util.ArrayList;

public class Estabelecimento {
	private String nome;
	private Gerente gerente;
	
	ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
	ArrayList<Produto> produtos = new ArrayList<Produto>();
	
	public Estabelecimento(String nome, Gerente gerente) {
		this.nome = nome;
		this.gerente = gerente;
		funcionarios.add(gerente);
	}
	
	public String getNome() {
		return nome;
	}

	public Gerente getGerente() {
		return gerente;
	}

	public ArrayList<Funcionario> getFuncionarios() {
		return funcionarios;
	}

	public ArrayList<Produto> getProdutos() {
		return produtos;
	}

	
	
	

}
