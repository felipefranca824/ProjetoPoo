package ClassesFuncionais;

import java.util.Random;

public class Funcionario {
	private String nome;
	private int numMatricula;
	private String telefone;
	private double comissao;
	private Login login;
	
	private static Random aleatorio = new Random();
	
	public Funcionario(String nome, String telefone, String username, String senha) {
		this.nome = nome;
		this.telefone = telefone;
		this.comissao = 0;
		this.login = new Login(username, senha);
		
		int numGerado1 = 0, numGerado2 = 0;
		
		for (int i = 0; i < 2; i++) {
			numGerado1 = aleatorio.nextInt(100000);
			numGerado2 = aleatorio.nextInt(100000);
		}
		this.numMatricula = numGerado1 + numGerado2;
		
	}

	public String getNome() {
		return nome;
	}

	public int getNumMatricula() {
		return numMatricula;
	}

	public String getTelefone() {
		return telefone;
	}

	public double getComissao() {
		return comissao;
	}
	
	public boolean registrarProduto(Produto produto, Compra compra) {
		compra.adicionarProduto(produto);
		return true;
	}
	
	public boolean finalizarCompra(Compra compra) {
		this.comissao += compra.getValor() * 0.10;
		return true;
	}

	public Login getLogin() {
		return login;
	}

	
	/*public static void main(String[] args) {
		Produto produto = new Produto("pizza", 23.00, 566688888);
		
		ProdutoPedido produtoPedido = new ProdutoPedido(produto, 7);
		Pedido pedido = new Pedido(produtoPedido);
		produto = new Produto("carne", 14.00, 50688888);
		
		produtoPedido = new ProdutoPedido(produto, 9);
		Compra compra = new Compra(pedido);
		pedido = new Pedido(produtoPedido);
		
		compra.adicionarPedido(pedido);
		
		
		
	}*/

}
