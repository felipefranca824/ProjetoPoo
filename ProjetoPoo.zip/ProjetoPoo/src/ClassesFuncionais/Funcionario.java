package ClassesFuncionais;

import java.util.ArrayList;
import java.util.Random;

public class Funcionario {
	private String nome;
	private int numMatricula;
	private String telefone;
	private double comissao;
	private Login login;
	ArrayList<Compra> compras = new ArrayList<Compra>();
	private static Random aleatorio = new Random();
	
	public Funcionario(String nome, String telefone, String username, String senha) {
		this.nome = nome;
		this.telefone = telefone;
		this.comissao = 0;
		this.login = new Login(username, senha);
		
		int numGerado1 = 0, numGerado2 = 0;
		
		for (int i = 0; i < 2; i++) {
			numGerado1 = aleatorio.nextInt(100000);
			numGerado2 = aleatorio.nextInt(100000);
		}
		this.numMatricula = numGerado1 + numGerado2;
		
	}

	public String getNome() {
		return nome;
	}

	public int getNumMatricula() {
		return numMatricula;
	}

	public String getTelefone() {
		return telefone;
	}

	public double getComissao() {
		return comissao;
	}
	
	public boolean registrarProduto(Produto produto, Compra compra) {
		compra.adicionarProduto(produto);
		return true;
	}
	
	public boolean finalizarCompra(Compra compra) {
		this.comissao += compra.getValor() * 0.10;
		return true;
	}

	public Login getLogin() {
		return login;
	}
	
	public Funcionario realizarLogin(Estabelecimento estabelecimento, String username, String senha) {
		
		for (Funcionario funcionario : estabelecimento.getFuncionarios()) {
			if(funcionario.getLogin().getUsername().equals(username)) {
				if(funcionario.getLogin().getSenha().equals(senha)) {
					return funcionario;
				}
			}
		}
		
		return null;
	}
	
	public String verMenu() {
		String menu = "Vendo menu de Funcionario";
		return menu;
	}
	
	public Produto buscarProduto(int codigo, Estabelecimento estabelecimento) {
		for (Produto produto : estabelecimento.getProdutos()) {
			if(produto.getCodigoDeBarras() == codigo) {
				return produto;
			}
		}
		
		return null;
	}
	
	public Produto buscarProduto(String nome, Estabelecimento estabelecimento) {
		for (Produto produto : estabelecimento.getProdutos()) {
			if(produto.getNome().equalsIgnoreCase(nome)) {
				return produto;
			}
		}
		
		return null;
	}
	
	public boolean vender(Compra compra) {
		compras.add(compra);
		return true;
	}
	
	
	/*public static void main(String[] args) {
		/*
		Produto produto = new Produto("pizza", 23.00, 566688888);
		
		ProdutoPedido produtoPedido = new ProdutoPedido(produto, 7);
		Pedido pedido = new Pedido(produtoPedido);
		produto = new Produto("carne", 14.00, 50688888);
		
		produtoPedido = new ProdutoPedido(produto, 9);
		Compra compra = new Compra(pedido);
		pedido = new Pedido(produtoPedido);
		
		compra.adicionarPedido(pedido);
		Gerente gerente = new Gerente("Felipe", "90000000","Felipe","1234");
		Funcionario funcionario = new Funcionario("djchbkc", "123455", "123", "11");
		Estabelecimento estabelecimento = new Estabelecimento("Americanas", gerente);
		
		gerente.cadastrarFuncionario(funcionario, estabelecimento);
		
		Funcionario funcionario2 = funcionario.realizarLogin(estabelecimento, "Felipe", "1234");
		
		if(funcionario2.getClass().getSimpleName().equals("Gerente")) {
			System.out.println("Cadastrando funcionario");
		}*/
		
	//}

}
