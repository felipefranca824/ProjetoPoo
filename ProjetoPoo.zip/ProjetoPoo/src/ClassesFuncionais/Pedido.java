package ClassesFuncionais;

import java.util.ArrayList;

public class Pedido {
	
	private ArrayList <ProdutoPedido> itensPedido = new ArrayList<ProdutoPedido>();
	public Pedido(ProdutoPedido produtoPedido) {
		itensPedido.add(produtoPedido);
	}

}
