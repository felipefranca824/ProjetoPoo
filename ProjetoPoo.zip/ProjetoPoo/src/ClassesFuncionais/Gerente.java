package ClassesFuncionais;

public class Gerente extends Funcionario {
	public Gerente(String nome, String telefone, String username, String senha) {
		super(nome, telefone, username, senha);
	}
	
	public boolean cadastrarFuncionario(Funcionario funcionario, Estabelecimento estabelecimento) {
		estabelecimento.funcionarios.add(funcionario);
		return true;
	}
	
	public boolean removerFuncionario(Funcionario funcionario, Estabelecimento estabelecimento) {
		estabelecimento.funcionarios.remove(funcionario);
		return true;
	}
	public boolean cadastrarProduto(Produto produto, Estabelecimento estabelecimento) {
		estabelecimento.produtos.add(produto);
		return true;
	}
	
	public boolean removerProduto(Produto produto, Estabelecimento estabelecimento) {
		estabelecimento.produtos.remove(produto);
		return true;
	}
	
	public boolean darDesconto(String senha, Compra compra, double taxa) {
		if(this.getLogin().getSenha().equals(senha)) {
			taxa = taxa / 100;
			compra.setValor(compra.getValor() - (compra.getValor() * taxa));  
			return true;
		}
		return false;
	}
	
}
