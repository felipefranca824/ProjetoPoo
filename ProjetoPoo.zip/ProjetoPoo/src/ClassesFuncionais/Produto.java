package ClassesFuncionais;

public class Produto {
	private String nome;
	private double preco;
	private int codigoDeBarras;
	
	public Produto(String nome, double preco, int codigoDeBarras) {
		this.codigoDeBarras = codigoDeBarras;
		this.nome = nome;
		this.preco = preco;
	}

	public String getNome() {
		return nome;
	}

	public double getPreco() {
		return preco;
	}

	public int getCodigoDeBarras() {
		return codigoDeBarras;
	}

}
